﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SILogic.Model
{
    public class WorkerByHours : WorkerWithCategory
    {
        //public double TimeWorked { get; set; }

    }
}
