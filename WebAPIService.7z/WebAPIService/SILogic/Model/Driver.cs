﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SILogic.Model
{
    public class Driver : WorkerByHours
    {

    }
}
