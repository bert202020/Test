﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SILogic.Model
{
    public class Category
    {

        public string Name { get; set; }
        public double Ratio { get; set; }
    }
}
